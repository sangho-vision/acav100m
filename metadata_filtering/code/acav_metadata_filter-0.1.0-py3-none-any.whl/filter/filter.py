import re
import json
# import copy
from itertools import chain
from subprocess import check_output
from collections import defaultdict
import argparse
try:
    import importlib.resources as pkg_resources
except:
    import importlib_resources as pkg_resources

import nltk
import fasttext
from tqdm import tqdm


''' metadata filtering pipeline
1. duration: duration
2. language: text
3. gaming_category: category
4. artist_keywords: text, category
5. gaming_keywords: text
6. animation_keywords: text
7. officialvideo_keywords: text
8. tutorial_keywords: text(stemmed)
'''


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('in_path', nargs=1, default=None, type=str)
    parser.add_argument('out_path', nargs=1, default=None, type=str)
    parser.add_argument('-t', '--test-each', action='store_true')
    args = parser.parse_args()
    args.in_path = args.in_path[0]
    args.out_path = args.out_path[0]
    return args


def wc(filename):
    return int(check_output(["wc", "-l", filename]).split()[0])


def load_csv(path):
    # csv
    result = []
    if path.is_file():
        with open(path, 'r') as f:
            header = True
            for line in f:
                if header:
                    # skip header
                    header = False
                    continue
                line = line.split(',')
                line = [v for v in line if len(v) > 0]
                result.append(' '.join(line).strip().lower())

        result = [v.split(' ') for v in result]
        return result
    else:
        return None


def get_unique(x):
    x = [' '.join(v) for v in x]
    x = list(set(x))  # unique
    x = [v.split(' ') for v in x]

    return x


def load_keyword(path):
    keywords = load_csv(path)
    return get_unique(keywords)


class Preprocessor:
    def __init__(self):
        self.url_reg = re.compile(r'(https|http)?:\/\/(\w|\.|\/|\?|\=|\&|\%)*\b', flags=re.MULTILINE)

    def __call__(self, row):
        return self.preprocess_row(row)

    def preprocess_row(self, row):
        row = row.split('\t')
        if len(row) != 2:
            return None
        vid, data = row
        data = json.loads(data)
        fields = data['LatestDAFeature']
        text = self.get_text(fields)
        category = fields['YouTubeCategory']

        ''' use VideoLength, fallback to Duration, then use default value of 0 '''
        duration = fields['VideoLength']
        if duration and duration.isnumeric():
            duration = int(duration) - 1  # VideoLength = Duration + 1
        else:
            # fallback to duration
            duration = data['MediaVersionList'][0]['Duration']
            if duration and duration.isnumeric():
                duration = int(duration)
            else:
                # no duration found
                duration = 0
        return vid, text, category, duration

    @staticmethod
    def check_key_in(data, key, dtype=str):
        return data[key] if key in data and isinstance(data[key], dtype) else ''

    def get_text(self, fields):
        title = self.check_key_in(fields, 'Title', str)
        desc = self.check_key_in(fields, 'Description', str)
        texts = ' '.join([title, desc])
        texts = texts.lower()
        texts = re.sub(self.url_reg, '', texts)
        return texts


class LanguageDetector:
    def __init__(self):
        # Hardcode most frequent languages up to cumulative ratio 0.9
        '''
        self.major_languages = ['english', 'spanish', 'portuguese', 'russian',
                                'japanese', 'french', 'german', 'korean']
                                '''
        self.major_languages = ['en', 'es', 'pt', 'ru', 'ja', 'fr', 'de', 'ko']
        self.init_fasttext()

    def init_fasttext(self):
        print(__name__)
        with pkg_resources.path('filter.statics', 'lid.176.ftz') as path:
            model = fasttext.load_model(str(path))
        self.model = model

    def run(self, text):
        return self.model.predict(text, k=1)[0][0][-2:]

    def __call__(self, text):
        return self.run(text)

    def filter_major(self, text):
        detected = self.run(text).lower()
        return detected in self.major_languages


class Stemmer:
    def __init__(self):
        self.char_reg = re.compile(r'[a-zA-Z]')
        self.stemmer = nltk.stem.PorterStemmer()

        # prepare stopwords
        nltk.download('stopwords')

        stopword_languages = ['english', 'french', 'spanish', 'portuguese', 'german', 'russian']
        self.stop_words = [nltk.corpus.stopwords.words(lang) for lang in stopword_languages]
        self.stop_words = list(chain(*self.stop_words))  # flatten

    def remove_none_words(self, data):
        return [word for word in data if not self.is_none_word(word)]

    def is_none_word(self, data):
        return re.search(self.char_reg, data) is None

    def stem(self, text):
        return [self.stemmer.stem(word) for word in text]

    def run(self, text):
        text = [w for w in text if w not in self.stop_words]
        text = self.remove_none_words(text)
        text = self.stem(text)
        return text

    def __call__(self, text):
        return self.run(text)


class Filter:
    def __init__(self, keywords):
        self.keywords = keywords
        self.language_detector = LanguageDetector()
        self.stemmer = Stemmer()

    @staticmethod
    def filter_duration(duration):
        return 30 <= duration <= 597

    def filter_language(self, text):
        return self.language_detector.filter_major(text)

    def tokenize(self, data):
        return nltk.word_tokenize(data)

    @staticmethod
    def is_sublist(long_list, short_list):
        x = long_list
        y = short_list
        occ = [i for i, a in enumerate(x) if a == y[0]]
        for b in occ:
            if x[b: b + len(y)] == y:
                return True
            if len(occ) - 1 == occ.index(b):
                return False
        return False

    def filter_keywords(self, text, keyword_name, stem=False):
        keywords = self.keywords[keyword_name]
        if stem:
            # text = self.stemmer(copy.deepcopy(text))
            text = self.stemmer(text)
        for keyword in keywords:
            if self.is_sublist(text, keyword):
                return False
        return True

    def filter(self, vid, text, category, duration):
        if not self.filter_duration(duration):
            return False
        if not self.filter_language(text):
            return False
        text = self.tokenize(text)
        if category and category.lower() == 'gaming':
            return False
        if category and category.lower() == 'music' and not self.filter_keywords(text, 'artist'):
            return False
        if not self.filter_keywords(text, 'gaming'):
            return False
        if not self.filter_keywords(text, 'animation'):
            return False
        if not self.filter_keywords(text, 'officialvideo'):
            return False
        if not self.filter_keywords(text, 'tutorial', stem=True):
            return False
        return True

    def test_each(self, vid, text, category, duration):
        result = {}
        result['duration'] = not self.filter_duration(duration)
        result['language'] = not self.filter_language(text)
        text = self.tokenize(text)
        result['category_gaming'] = category.lower() == 'gaming'
        result['keywords_artist'] = category.lower() == 'music' and not self.filter_keywords(text, 'artist')
        result['keywords_gaming'] = not self.filter_keywords(text, 'gaming')
        result['keywords_animation'] = not self.filter_keywords(text, 'animation')
        result['keywords_officialvideo'] = not self.filter_keywords(text, 'officialvideo')
        result['keywords_tutorial'] = not self.filter_keywords(text, 'tutorial', stem=True)
        return result

    def __call__(self, *args, **kwargs):
        return self.filter(*args, **kwargs)


def load_keywords():
    with pkg_resources.path('filter.statics', 'keywords') as path:
        keyword_paths = list(path.glob('*.csv'))
        keywords = {path.stem: load_keyword(path) for path in keyword_paths}
    return keywords


def run_file(in_path, out_path):
    keywords = load_keywords()
    preprocessor = Preprocessor()
    filters = Filter(keywords)

    num_lines = wc(in_path)
    num_out_lines = 0
    with open(out_path, 'w') as out_f:
        with open(in_path, 'r') as in_f:
            for line in tqdm(in_f, total=num_lines):
                fields = preprocessor(line.strip())
                if fields is not None:
                    flag = filters(*fields)
                    if flag:
                        out_f.write(line)
                        num_out_lines += 1
    print("Done. {}/{}({}%) lines left".format(num_out_lines, num_lines,
                                               (num_out_lines / num_lines * 100)))


def test_each(in_path):
    keywords = load_keywords()
    preprocessor = Preprocessor()
    filters = Filter(keywords)

    num_lines = wc(in_path)
    num_out_lines = 0
    oks = defaultdict(lambda: 0)
    with open(in_path, 'r') as in_f:
        for line in tqdm(in_f, total=num_lines):
            fields = preprocessor(line.strip())
            if fields is not None:
                flags = filters.test_each(*fields)
                for k, flag in flags.items():
                    oks[k] += int(not flag)
    for k, ok in oks.items():
        num_out_lines = ok
        print("{}: {}/{}({}%) lines left".format(k,
                                                 num_out_lines, num_lines,
                                                 (num_out_lines / num_lines * 100)))


def main():
    args = parse_args()
    if args.test_each:
        test_each(args.in_path)
    else:
        run_file(args.in_path, args.out_path)


if __name__ == '__main__':
    main()
